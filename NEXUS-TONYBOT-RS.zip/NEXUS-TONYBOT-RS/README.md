# NEXUS × TONYBOT — Rust Kernel, Python Strategy Layer

Merges NEXUS (signal/dashboard) and TONYBOT (PySide6 GUI + strategy +
execution) into one system, with the hot path rewritten in Rust and
everything library-dependent or I/O-bound left in Python. See
`docs/MIGRATION_PLAN.md` for the full reasoning; short version below.

## What moved to Rust, and why

| Component | Language | Why |
|---|---|---|
| Risk engine (hard caps, exposure math, drawdown/loss breakers) | **Rust** | Called on every single quote before it can become an order; must be fast, deterministic, and impossible to accidentally duplicate/drift across languages |
| Order lifecycle state machine | **Rust** | Illegal transitions (e.g. PROPOSED → SUBMITTED, skipping the gate) must be structurally rejected, not just conventionally avoided |
| Journal (SQLite) | **Rust** | Every transition writes here before anything else sees it; restart recovery depends on this being correct and fast |
| Message bus | **Rust** | Per-adapter isolation so one adapter's rate-limit backoff can't stall another |
| Adapters (Binance, Polymarket, Jupiter/Solana) | Python | Pure I/O against libraries that only exist in Python (`ccxt`, `py-clob-client`, `solana-py`); no latency win from Rust here |
| Strategy DSL (schema, compiler, validator) | Python | Cold path — loaded per strategy version, not per-tick; Pydantic + PyYAML are the right tools |
| AI router / reflector / event analyst | Python | Pure HTTP against free-tier LLM APIs; must degrade to Rust's deterministic rules on failure, not the other way around |
| GUI | Python (PySide6) | No Rust GUI framework matches PySide6's maturity for this |
| Backtester, ML ensemble | Python | pandas/numpy/LightGBM ecosystem |

The boundary is simple: **if it's on the path between "the LLM/strategy
wants to trade" and "money moves," it's Rust.** Everything upstream of
that (signal generation, GUI, AI commentary) is Python and can be as slow
or as flaky as free-tier APIs make it — the Rust kernel never trusts it.

## Repo layout

```
rust-core/
  kernel/      # risk_engine, order_lifecycle, journal, message_bus — pure Rust, no Python deps
  pybridge/    # PyO3 bindings — builds the `nexus_kernel` Python extension module
python-layer/
  adapters/    # BaseAdapter contract + per-market adapters (ports from NEXUS/TONYBOT)
  strategy/    # DSL schema/compiler/validator + .yaml strategy definitions
  ai/          # free-tier LLM router, reflector, event analyst
  ui/          # PySide6 dashboard
  tests/       # contract tests proving Python calls straight through to the Rust gate
docs/
  MIGRATION_PLAN.md
```

## Build & run

```bash
# 1. Build the Rust kernel as a Python extension
cd rust-core
cargo test                                            # Rust unit tests (risk_engine, order_lifecycle, journal, bus)
pip install maturin
maturin develop --release -m pybridge/Cargo.toml       # installs `nexus_kernel` into your active venv

# 2. Python layer
cd ../python-layer
pip install -r requirements.txt
pytest tests/                                          # proves Python → Rust gate round-trips correctly
python ui/main_window.py                               # launch the GUI
```

## Status

This is a scaffold: the risk engine, order lifecycle, journal, message
bus, and the PyO3 bridge are real, tested Rust code. The adapters
(Binance/Polymarket/Jupiter), DSL compiler, reflector loop, and GUI panels
are stubs/ports carrying over the original spec's contracts — fill them in
per `docs/MIGRATION_PLAN.md`'s phase order.
