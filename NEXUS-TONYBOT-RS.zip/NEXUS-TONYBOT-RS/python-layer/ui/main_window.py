"""
PySide6 dashboard (ported from TONYBOT). GUI is Python-only by necessity —
this is a thin shell showing where the market-selector tab (one per
adapter) plugs in. Fill in with TONYBOT's existing widgets per-tab.
"""

from __future__ import annotations

import sys

from PySide6.QtWidgets import QApplication, QLabel, QMainWindow, QTabWidget


class MarketTab(QLabel):
    def __init__(self, market_name: str):
        super().__init__(f"{market_name} — wire up adapter status, open positions, journal view here")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("NEXUS × TONYBOT")
        tabs = QTabWidget()
        tabs.addTab(MarketTab("Perp (Binance)"), "Perp")
        tabs.addTab(MarketTab("Polymarket"), "Polymarket")
        tabs.addTab(MarketTab("Memecoin (Solana)"), "Memecoin")
        self.setCentralWidget(tabs)


def main():
    app = QApplication(sys.argv)
    win = MainWindow()
    win.resize(1200, 800)
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
