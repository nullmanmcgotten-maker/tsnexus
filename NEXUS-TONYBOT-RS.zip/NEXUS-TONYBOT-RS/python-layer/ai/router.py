"""
Free-tier cascade router (spec §7.1). Stays in the Python layer: it is
pure HTTP I/O against four different free-tier chat completion APIs, with
no latency pressure that would justify Rust, and the failure mode (all
providers return 429) must degrade to deterministic rules living in the
Python strategy layer, not block the Rust risk gate.
"""

from __future__ import annotations

import hashlib
import json
import os
import time

import httpx

PROVIDERS = [
    ("groq", "https://api.groq.com/openai/v1", "openai/gpt-oss-120b"),
    ("gemini", "https://generativelanguage.googleapis.com/v1beta/openai/", "gemini-2.5-flash"),
    ("cerebras", "https://api.cerebras.ai/v1", "llama-3.3-70b"),
    ("mistral", "https://api.mistral.ai/v1", "mistral-small-latest"),
]

_CACHE: dict[str, tuple[float, str]] = {}


def _cache_key(prompt: str) -> str:
    return hashlib.sha256(prompt.encode()).hexdigest()


async def ask(prompt: str, max_tokens: int = 256, ttl_seconds: int | None = 3600) -> str:
    """Cascades through PROVIDERS on failure/429. Returns "" (never raises)
    if every provider fails, so callers can fall back to deterministic
    rules per the "AI is optional enrichment" constraint (spec §1.3).
    """
    key = _cache_key(prompt)
    if ttl_seconds is not None and key in _CACHE:
        ts, val = _CACHE[key]
        if time.time() - ts < ttl_seconds:
            return val

    async with httpx.AsyncClient(timeout=20) as client:
        for name, base, model in PROVIDERS:
            api_key = os.environ.get(f"{name.upper()}_API_KEY")
            if not api_key:
                continue
            try:
                r = await client.post(
                    f"{base}/chat/completions",
                    headers={"Authorization": f"Bearer {api_key}"},
                    json={
                        "model": model,
                        "temperature": 0.1,
                        "max_tokens": max_tokens,
                        "messages": [{"role": "user", "content": prompt}],
                    },
                )
                if r.status_code == 200:
                    content = r.json()["choices"][0]["message"]["content"]
                    if ttl_seconds is not None:
                        _CACHE[key] = (time.time(), content)
                    return content
            except Exception:
                continue
    return ""


async def reflect_failed_trade(trade: dict, strategy: dict) -> dict:
    """Spec §7.2. One proposed parameter change per losing trade. The
    caller is responsible for backtest-gating the proposal before it can
    ever become a new strategy_versions row — this function only diagnoses.
    """
    prompt = f"""Diagnose this failed trade and propose exactly ONE parameter change.
Trade: {json.dumps(trade)}
Current params: {json.dumps(strategy['params'])}
Ranges: {json.dumps(strategy['param_ranges'])}
Return JSON only: {{"diagnosis":"...","param":"...","old":...,"new":...}}"""
    raw = await ask(prompt, ttl_seconds=None)  # reflections are unique per trade, never cached
    try:
        return json.loads(raw)
    except Exception:
        return {"diagnosis": "parse_failed", "accepted": False}


async def event_probability_estimate(market_title: str, news_snippet: str = "") -> float | None:
    """Spec §7.3. Returns a probability in [0,1], or None on failure/parse
    error. Callers must still run this through the min-liquidity guard and
    the risk kernel — this never generates an order by itself.
    """
    prompt = f"""Estimate the probability (0.0 to 1.0) that this event resolves YES.
Market: {market_title}
Recent context: {news_snippet or "none"}
Return JSON only: {{"probability": 0.0}}"""
    raw = await ask(prompt)
    try:
        return float(json.loads(raw)["probability"])
    except Exception:
        return None
