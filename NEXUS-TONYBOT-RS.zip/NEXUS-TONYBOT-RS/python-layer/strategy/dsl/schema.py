"""
Spec §6.2. Stays Python: Pydantic validation + PyYAML are the right tools,
and this is cold-path (loaded once per strategy version, not per-tick), so
there is no case for Rust here. The Rust kernel never sees DSL — it only
ever sees the Quote objects a compiled strategy emits.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel


class Trigger(BaseModel):
    indicator: Literal[
        "rsi", "macd", "volume_spike", "price_above_ema",
        "bb_breakout", "prob_deviation", "time_to_resolution",
    ]
    params: dict
    condition: str  # e.g. "< 30", "> 1.5", "abs() > 0.08"


class Guard(BaseModel):
    name: Literal[
        "safety_filter", "max_notional_usd", "regime",
        "liquidity_min_usd", "funding_budget",
    ]
    params: dict


class Exit(BaseModel):
    stop_loss: dict | None = None
    take_profit: dict | None = None
    timeout_minutes: int | None = None


class StrategyDSL(BaseModel):
    id: str
    market: Literal["perp_binance", "polymarket", "solana_memecoin"]
    triggers: list[Trigger]
    guards: list[Guard]
    exit: Exit
    params: dict[str, float]
    param_ranges: dict[str, tuple[float, float]]


# Market-specific indicator availability (spec §6.3 rule 2: "Polymarket has
# no RSI"). The validator consults this before a DSL can be loaded.
MARKET_INDICATORS: dict[str, set[str]] = {
    "perp_binance": {"rsi", "macd", "volume_spike", "price_above_ema", "bb_breakout"},
    "solana_memecoin": {"rsi", "volume_spike", "price_above_ema"},
    "polymarket": {"prob_deviation", "time_to_resolution"},
}


def validate(dsl: StrategyDSL) -> list[str]:
    """Returns a list of validation errors; empty list = loadable."""
    errors: list[str] = []

    allowed_indicators = MARKET_INDICATORS.get(dsl.market, set())
    for trig in dsl.triggers:
        if trig.indicator not in allowed_indicators:
            errors.append(f"indicator '{trig.indicator}' not valid for market '{dsl.market}'")

    for key in dsl.params:
        if key not in dsl.param_ranges:
            errors.append(f"param '{key}' has no declared range")

    guard_names = {g.name for g in dsl.guards}
    if dsl.market == "solana_memecoin" and "safety_filter" not in guard_names:
        errors.append("solana_memecoin strategies must include the safety_filter guard")
    if "max_notional_usd" not in guard_names:
        errors.append("every strategy must declare a max_notional_usd guard")

    return errors
