"""
Frozen adapter contract (spec §3.1). Unchanged by the Rust migration on
purpose: adapters are I/O-bound (HTTP/WS to Binance, Polymarket, Jupiter)
and gain nothing from Rust, while the libraries they need (ccxt, web3,
solana-py, py_clob_client) are Python-only. What changes is that
`risk_gate()` below no longer contains risk math itself — it calls the
compiled Rust kernel so there is exactly one implementation of the caps.
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum

import nexus_kernel  # built from rust-core/pybridge via `maturin develop`


class Side(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class Market(str, Enum):
    PERP = "perp_binance"
    POLYMARKET = "polymarket"
    MEMECOIN = "solana_memecoin"


class CapExceeded(Exception):
    pass


@dataclass
class Quote:
    adapter: Market
    symbol: str
    side: Side
    price: float
    size: float
    notional_usd: float          # ALWAYS the authoritative number for risk
    slippage_bps: float = 0.0
    metadata: dict = field(default_factory=dict)

    def to_kernel_dict(self) -> dict:
        return {
            "adapter": self.adapter.value,
            "symbol": self.symbol,
            "side": self.side.value,
            "price": self.price,
            "size": self.size,
            "notional_usd": self.notional_usd,
            "slippage_bps": self.slippage_bps,
            "metadata": self.metadata,
        }


@dataclass
class OrderResult:
    order_id: str | None
    status: str                  # FILLED | PARTIAL | REJECTED | UNKNOWN
    filled_size: float
    avg_price: float | None
    raw: dict = field(default_factory=dict)


def risk_gate(quote: Quote, snapshot: dict) -> tuple[bool, str]:
    """Delegates to the Rust kernel. `snapshot` carries the portfolio
    numbers the Python journal/portfolio layer already tracks:
    total_capital_usd, total_exposure_usd, market_exposure_usd,
    daily_loss_pct, drawdown_pct, and (perp only) projected_funding_cost_usd
    / funding_budget_usd.
    """
    return nexus_kernel.gate(quote.to_kernel_dict(), snapshot)


class BaseAdapter(ABC):
    market: Market

    @abstractmethod
    async def health(self) -> dict: ...

    @abstractmethod
    async def get_balance_usd(self) -> float: ...

    @abstractmethod
    async def quote(self, symbol: str, side: Side, notional_usd: float) -> Quote: ...

    async def submit(self, quote: Quote, dry_run: bool = True) -> OrderResult:
        """Default submit() always gates through the Rust kernel before
        calling the adapter-specific `_submit_impl`. Subclasses override
        `_submit_impl`, not `submit`, so the gate can never be bypassed.
        """
        snapshot = await self._portfolio_snapshot()
        approved, reason = risk_gate(quote, snapshot)
        if not approved:
            if reason == "hard_cap_exceeded":
                raise CapExceeded(f"{quote.adapter}: notional {quote.notional_usd} exceeds hard cap")
            return OrderResult(order_id=None, status="REJECTED", filled_size=0.0,
                                avg_price=None, raw={"reason": reason})
        return await self._submit_impl(quote, dry_run)

    @abstractmethod
    async def _submit_impl(self, quote: Quote, dry_run: bool) -> OrderResult: ...

    @abstractmethod
    async def _portfolio_snapshot(self) -> dict: ...

    @abstractmethod
    async def cancel(self, order_id: str) -> bool: ...

    @abstractmethod
    async def positions(self) -> list[dict]: ...
