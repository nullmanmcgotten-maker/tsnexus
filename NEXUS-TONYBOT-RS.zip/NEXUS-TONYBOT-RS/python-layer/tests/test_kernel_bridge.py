"""
Run with: pytest python-layer/tests/test_kernel_bridge.py
Requires `maturin develop --release -m rust-core/pybridge/Cargo.toml` to
have been run first, in the same venv pytest uses.
"""

from adapters.base import Market, Quote, Side, risk_gate


def _snapshot(**overrides):
    base = dict(
        total_capital_usd=10_000.0,
        total_exposure_usd=0.0,
        market_exposure_usd=0.0,
        daily_loss_pct=0.0,
        drawdown_pct=0.0,
    )
    base.update(overrides)
    return base


def test_memecoin_hard_cap_rejected_via_rust_kernel():
    q = Quote(adapter=Market.MEMECOIN, symbol="DOGSHIT", side=Side.BUY,
              price=0.001, size=30000, notional_usd=30.0,
              metadata={"safety": {"passed": True}})
    approved, reason = risk_gate(q, _snapshot())
    assert not approved
    assert reason == "hard_cap_exceeded"


def test_memecoin_without_safety_pass_rejected():
    q = Quote(adapter=Market.MEMECOIN, symbol="DOGSHIT", side=Side.BUY,
              price=0.001, size=10000, notional_usd=10.0,
              metadata={"safety": {"passed": False}})
    approved, reason = risk_gate(q, _snapshot())
    assert not approved
    assert reason == "safety_filter_missing_or_failed"


def test_polymarket_within_caps_approved():
    q = Quote(adapter=Market.POLYMARKET, symbol="EVT-1", side=Side.BUY,
              price=0.45, size=100, notional_usd=45.0)
    approved, reason = risk_gate(q, _snapshot())
    assert approved
    assert reason == "approved"
